  
                                        
                                                                 
                                                              
                                 
                               
  
                      


  
                                                   
  
var g_ActiveTournamentInfo =
{
	eventid: 18,
	organization: 'pgl',
	location: 'stockh2021',
	stickerid_graffiti: 5078,
	itemid_pass: 4796,
	itemid_pack: 4801,
	itemid_charge: 4802,
};


  
                                                         
  
var g_ActiveTournamentTeams =
[
	                    
	{
		teamid: 1,
		team: 'nip',
		stickerid_graffiti: 5054,
		team_group: 'legends',
	},
	        
	{
		teamid: 85,
		team: 'furi',
		stickerid_graffiti: 5055,
		team_group: 'legends',
	},
	                
	{
		teamid: 12,
		team: 'navi',
		stickerid_graffiti: 5056,
		team_group: 'legends',
	},
	           
	{
		teamid: 89,
		team: 'vita',
		stickerid_graffiti: 5057,
		team_group: 'legends',
	},
	              
	{
		teamid: 48,
		team: 'liq',
		stickerid_graffiti: 5058,
		team_group: 'legends',
	},
	                
	{
		teamid: 63,
		team: 'gamb',
		stickerid_graffiti: 5059,
		team_group: 'legends',
	},
	             
	{
		teamid: 59,
		team: 'g2',
		stickerid_graffiti: 5060,
		team_group: 'legends',
	},
	                
	{
		teamid: 98,
		team: 'evl',
		stickerid_graffiti: 5061,
		team_group: 'legends',
	},
	              
	{
		teamid: 81,
		team: 'spir',
		stickerid_graffiti: 5062,
		team_group: 'challengers',
	},
	           
	{
		teamid: 60,
		team: 'astr',
		stickerid_graffiti: 5063,
		team_group: 'challengers',
	},
	              
	{
		teamid: 102,
		team: 'pain',
		stickerid_graffiti: 5064,
		team_group: 'challengers',
	},
	       
	{
		teamid: 84,
		team: 'ence',
		stickerid_graffiti: 5065,
		team_group: 'challengers',
	},
	      
	{
		teamid: 69,
		team: 'big',
		stickerid_graffiti: 5066,
		team_group: 'challengers',
	},
	                  
	{
		teamid: 103,
		team: 'ride',
		stickerid_graffiti: 5067,
		team_group: 'challengers',
	},
	         
	{
		teamid: 95,
		team: 'hero',
		stickerid_graffiti: 5068,
		team_group: 'challengers',
	},
	       
	{
		teamid: 106,
		team: 'mouz',
		stickerid_graffiti: 5069,
		team_group: 'challengers',
	},
	                 
	{
		teamid: 104,
		team: 'shrk',
		stickerid_graffiti: 5070,
		team_group: 'contenders',
	},
	        
	{
		teamid: 74,
		team: 'tyl',
		stickerid_graffiti: 5071,
		team_group: 'contenders',
	},
	            
	{
		teamid: 53,
		team: 'ren',
		stickerid_graffiti: 5072,
		team_group: 'contenders',
	},
	           
	{
		teamid: 105,
		team: 'ent',
		stickerid_graffiti: 5073,
		team_group: 'contenders',
	},
	          
	{
		teamid: 67,
		team: 'god',
		stickerid_graffiti: 5074,
		team_group: 'contenders',
	},
	             
	{
		teamid: 31,
		team: 'vp',
		stickerid_graffiti: 5075,
		team_group: 'contenders',
	},
	                    
	{
		teamid: 101,
		team: 'cope',
		stickerid_graffiti: 5076,
		team_group: 'contenders',
	},
	            
	{
		teamid: 61,
		team: 'faze',
		stickerid_graffiti: 5077,
		team_group: 'contenders',
	},
];


  
                                                               
  

var g_ActiveTournamentStoreLayout =
[
	[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
	'#CSGO_TournamentPass_stockh2021_pack_tinyname'
	],
	[
	4803,                                
	4806,                               
	'#CSGO_crate_store_pack_stockh2021_legends_groupname'
	],
	[
	4804,                                    
	4807,                                   
	'#CSGO_crate_store_pack_stockh2021_challengers_groupname'
	],
	[
	4805,                                   
	4808,                                  
	'#CSGO_crate_store_pack_stockh2021_contenders_groupname'
	],
	[
	4816,                                    
	4817,                                    
	'#CSGO_crate_store_pack_stockh2021_signatures_groupname'
	],
];

var g_ActiveTournamentPasses =
[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
];


  
                                                     
  
